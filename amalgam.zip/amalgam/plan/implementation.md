# V15 — Nuclear Option: Closing the 0.016 Gap to 0.915

## Current Standing

| Version | Kaggle | Architecture |
|---------|--------|-------------|
| V13 (ours) | **0.898** | Our features + teammate's framework |
| V14 (teammate) | **0.899** | Teammate's exact V3 code |
| **Rival team** | **0.915** | Unknown |
| **Gap to close** | **+0.016** | Enormous in ML terms |

## Key Data Insights (from analysis)

| Fact | Implication |
|------|------------|
| 628/3897 (16.1%) test molecules appear in train with **some** target type | Cross-target info is available for a significant portion |
| 318 test Tg molecules have known Egc in train (11.5%) | Direct Egc→Tg knowledge transfer possible |
| 308 test Egc molecules have known Tg in train (22.8%) | Direct Tg→Egc knowledge transfer possible |
| 474 train structures have **both** Tg + Egc measurements | Multi-task relationship can be learned |
| Only 2 exact same-target overlaps (Tg) | Canonical override has minimal impact |
| 6 duplicate (canon, target_type) pairs with std 2.5–12°C | Some measurement noise in Tg data |

## The 0.016 Gap Analysis

At 0.899, we've exhausted the "better GBDT tuning" and "more diverse ensemble" strategies. The rival at 0.915 must be leveraging **information our models are ignoring**. Three high-value data signals remain untapped:

### Signal 1: Chemical Similarity to Known Targets
If two polymers have 90% structural similarity and one has Tg=200°C, the other is likely near 200°C. Our GBDT models can't reason this way — they process each molecule independently. **k-NN target features** make this relationship explicit.

### Signal 2: Cross-Target Correlation  
Tg and Egc are physically correlated (conjugated backbone → higher Egc AND higher Tg). For 628 test molecules with known opposite-target values in training, we can exploit this correlation directly. For the rest, we can predict it.

### Signal 3: Ensemble Diversity Gap
V13 and V14 score nearly the same but use **different features**. Blending them should cancel uncorrelated errors.

---

## Proposed Strategy (6 Components)

### 🏆 Component 1: V13 + V14 Meta-Ensemble Blend (Quick Win)

**Why:** V13 (0.898) and V14 (0.899) use different feature sets:
- V13: Our V11 descriptors (E-state, autocorrelation, Kappa/Chi, enhanced backbone)
- V14: Teammate's simpler custom features + FCFP + interaction cross-terms

Different features → different error patterns → blend reduces variance.

**How:**
- Load `submission_v13.csv` and `submission_v14.csv`  
- Grid search blend weight α ∈ [0.3, 0.7] on a held-out portion
- Since we can't validate locally without running both, use **α = 0.50** (equal blend)
- Expected: +0.001–0.003

> [!TIP]
> This is essentially free — just arithmetic on two CSV files. Can be tested immediately.

---

### 🧬 Component 2: Similarity-Based k-NN Target Features (HIGH IMPACT)

**Why:** This is probably the rival's secret weapon. For each molecule, we compute fingerprint similarity to all training molecules and use the target values of the most similar molecules as features. This creates an extremely strong prior.

**How:**
1. Compute Morgan R2 fingerprint for every molecule
2. For each molecule X (in OOF or test), compute Tanimoto similarity to all **training fold** molecules
3. Create features:
   - `knn_target_mean_k5`: Mean target of top-5 most similar training molecules
   - `knn_target_mean_k10`: Mean target of top-10
   - `knn_target_mean_k20`: Mean target of top-20
   - `knn_target_weighted_k10`: Similarity-weighted average of top-10
   - `knn_target_max_sim`: Similarity to most similar training molecule
   - `knn_target_best`: Target of the single most similar training molecule
   - `knn_target_std_k10`: Std of top-10 targets (uncertainty estimate)

**Critical anti-leak rule:** Within CV, k-NN features must use **only the training fold**. Never look at validation fold targets to compute k-NN features for validation molecules. This is implemented naturally in the per-fold loop.

**Expected: +0.005–0.012** (this is the biggest lever)

> [!IMPORTANT]
> This technique is legal under competition rules — no external data, just using the training set itself as a similarity lookup. It's essentially a learned nearest-neighbor regression.

---

### 🔄 Component 3: Cross-Target Prediction Features (MEDIUM-HIGH IMPACT)

**Why:** 474 training molecules have both Tg and Egc measurements. The correlation between Tg and Egc for these molecules lets us:
- For a Tg molecule: "What would its Egc be?" → use as feature
- For an Egc molecule: "What would its Tg be?" → use as feature

**How:**
1. Train a LightGBM model to predict Egc from molecular features (on the 2,028 Egc training samples)
2. Predict Egc for ALL Tg molecules (train + test) → add as feature `predicted_egc`
3. Similarly, train LightGBM to predict Tg → predict for all Egc molecules → add `predicted_tg`
4. For the 474 molecules with ground truth for both: use actual value instead of prediction
5. For the 628 test molecules with cross-target training data: use actual training value

**Anti-leak:** The cross-target prediction models are trained on their own target type's data (e.g., predict Egc is trained only on Egc rows). This doesn't leak same-target info.

**Expected: +0.003–0.006**

---

### 📊 Component 4: Target Transformation (MEDIUM IMPACT)

**Why:** Tg ranges from -118 to 490 (std=109), Egc from 0.1 to 9.9 (std=1.6). These very different scales and distributions may cause GBDT to allocate splits poorly. Transforming targets to uniform or normal distributions can help.

**How:**
- Apply `QuantileTransformer(output_distribution='normal')` to targets before training
- Train models on transformed targets
- Inverse-transform predictions back to original scale
- **Per-target type:** Separate transformers for Tg and Egc

**Expected: +0.001–0.003**

> [!NOTE]
> This is a subtle improvement. GBDT with squared loss effectively optimizes in the original target space. Transforming to a more uniform distribution means each split captures more meaningful structure.

---

### 🤖 Component 5: Expanded Model Zoo (MEDIUM IMPACT)

**Why:** V14 uses 11 models. More diversity = better ensemble IF the new models have different error patterns.

**Additional models to add:**
- **MLP Regressor** (2-layer neural net) — captures nonlinear feature interactions that trees miss
- **KNeighborsRegressor** (k=10, 20) on fingerprint features — directly leverages chemical similarity
- **ElasticNet** — regularized linear model, very different from tree-based
- **SVR** (RBF kernel, on top PCA components) — captures nonlinear patterns differently from trees
- **More XGBoost/LightGBM variants** with deliberately different architectures (very shallow depth=3, very deep depth=10)

**Total: ~18-20 models** (up from 11)

**Expected: +0.002–0.004**

---

### 🔁 Component 6: Iterative Pseudo-Labeling (EXPERIMENTAL)

**Why:** Use high-confidence model predictions on test data to augment training. If we're 95% confident in a prediction, adding it as training data reinforces the pattern.

**How:**
1. Generate V15 predictions on test set
2. Identify high-confidence predictions (low variance across models)
3. Add top ~500 most confident test predictions as pseudo-labels to training
4. Retrain the entire pipeline with augmented training data
5. Generate new predictions

**Safety:** Only use predictions where all 11+ models agree closely (std < 5% of target range). One iteration only (no iterative snowball).

**Expected: +0.001–0.003** (risky — could hurt if pseudo-labels are wrong)

---

## Expected Impact Summary

| Component | Est. Gain | Risk | Effort |
|-----------|-----------|------|--------|
| V13+V14 blend | +0.001–0.003 | Very low | 5 min |
| k-NN target features | +0.005–0.012 | Low | High |
| Cross-target features | +0.003–0.006 | Low | Medium |
| Target transformation | +0.001–0.003 | Very low | Low |
| Expanded model zoo | +0.002–0.004 | Low | Medium |
| Pseudo-labeling | +0.001–0.003 | Medium | Medium |
| **Total (non-additive)** | **+0.010–0.020** | — | — |

> [!IMPORTANT]
> Gains are NOT fully additive — there's overlap. Realistic target: **0.908–0.918 Kaggle**. The k-NN target features alone could account for ~60% of the rival's advantage.

## Execution Plan

### Phase 1: Quick Wins (test immediately)
1. Blend V13 + V14 CSVs → submit as V15-blend
2. If >0.900, we know the blend helps

### Phase 2: Core V15 Notebook (main effort)
Build one comprehensive notebook with ALL components:
- k-NN target features (Component 2)
- Cross-target prediction features (Component 3)
- Target transformation (Component 4)
- Expanded model zoo (Component 5)
- GroupKFold + per-fold impute/scale (from V13/V14)
- Constrained convex blending (from V14)

### Phase 3: Post-V15 Polish
- Blend V15 with V13/V14 for final submission
- Pseudo-labeling if V15 alone doesn't hit 0.915

## Open Questions

> [!IMPORTANT]
> **Runtime budget:** k-NN Tanimoto similarity computation for ~6K×6K molecules = ~36M comparisons per fold. On Kaggle's 2-core CPU, this could take 5-10 minutes. With 20 models × 5 folds on top of that, total runtime could hit 2-3 hours. Should I optimize with bulk Tanimoto via RDKit or use a sparse approximate approach?

> [!IMPORTANT]
> **Phase 1 immediate test:** Should I generate the V13+V14 blend CSV right now so you can submit it today while I build V15?

## Notebook Structure (V15)

```
Cell 1:  Imports
Cell 2:  Data loading + canonicalization
Cell 3:  Feature engineering (V13 features)
Cell 4:  Cross-target prediction features (Component 3)
Cell 5:  Feature preprocessing
Cell 6:  k-NN target feature computation (Component 2)  
Cell 7:  Target transformation setup (Component 4)
Cell 8:  Model configurations (Component 5, 18-20 models)
Cell 9:  Level-1 GroupKFold CV (per-fold impute+scale+kNN)
Cell 10: Constrained convex blending + RidgeCV stacking
Cell 11: Results comparison
Cell 12: Submission generation + optional V13/V14 blend
```
