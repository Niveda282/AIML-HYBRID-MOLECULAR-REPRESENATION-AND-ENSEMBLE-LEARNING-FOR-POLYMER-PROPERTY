
# V17 — Feature-Subset Pipeline Diversity: 0.902 → 0.910+

## Current Standing

| Version | Kaggle R² | What Changed |
|---|---|---|
| V15 blend | 0.901 | k-NN target features + cross-target + 19 models + target transform |
| V16 | **0.902** | Pruned dead models, multi-FP k-NN, multi-seed, Optuna-tuned, feature selection |
| Rival | 0.915 | Unknown |
| Gap remaining | +0.013 | |

## Diagnosis: Why the Next Gain Has to Come From Diversity, Not More Models

V16 already pushed the "more/better models on the same 6,775-feature matrix" lever about as far as it reasonably goes — 20 model configs, multi-seed averaging, Optuna-tuned top performers, importance-based feature pruning, and a two-meta-learner stack. The result was +0.001 (0.901→0.902). That's the signature of a model pool that has converged: every model sees the same k-NN-augmented, importance-filtered feature matrix, so their errors are highly correlated. Adding model #21 with slightly different hyperparameters buys almost nothing because it fails on the same molecules the other 20 fail on.

**Convex blend weights can only reweight existing errors — they can't manufacture disagreement that isn't there.** The only way to get a bigger blend lift is to give some models a genuinely different view of the data. Feature-subset pipelines do that directly: a model trained on fingerprints only cannot make the same mistake as a model trained on descriptors only, because they don't have access to the same information.

## Proposed Approach: Feature-Subset Pipelines (Ensemble of Ensembles)

Train a **reduced set of the strongest models** (not all 20 — see scoping below) on **3-4 different feature views** of the same molecules, instead of 1 view. Each view is a full slice of the existing V16 feature matrix (no new features computed) — this is a resourcing/architecture change, not a feature-engineering change, so it composes with everything already in V16.

| Pipeline | Features Used | Approx. Width | Why It Helps |
|---|---|---|---|
| A (current, from V16) | All 6,775 cols + multi-FP k-NN | ~6,850 | The existing best-performing baseline — kept as-is, not retrained |
| B (FP-only) | MFP1 + MFP2 + MFP3 + FCFP2 + MACCS (no RDKit descriptors, no custom feats, no k-NN) | ~6,465 | Pure structural similarity; forces the model to key off substructure patterns instead of leaning on a handful of dominant descriptors |
| C (Desc-only) | RDKit `CalcMolDescriptors` output + custom polymer features (backbone/side-chain/charge/topology feats from Cell 3) | ~600 | Physicochemical/topological signal only; no fingerprint sparsity, so trees split on continuous, physically meaningful features instead of hashed bits |
| D (k-NN + compact) | Multi-FP k-NN target features (21-42 cols depending on k-value expansion) + OOF cross-target feature + top-50 features by V16's already-computed importance ranking | ~75 | Nearest-neighbor-dominated, fundamentally different inductive bias — most of its signal is "what did similar molecules score," not molecular structure directly |

### Model scoping (this is the part I'm changing from your draft)

Running all 5 candidate models (`XGB_D7_MS`, `LGBM_L127`, `LGBM_L255`, `CB_D6`, `ET_Large`) × 3 multi-seed variants × 4 pipelines × 5 folds is 300 model fits **on top of** V16's existing ~240 fits. That's not a safe Kaggle CPU budget (V16 alone likely already runs multiple hours). I'm cutting scope two ways:

1. **Single-seed per model in the new pipelines** (drop the ×3 multi-seed multiplier for B/C/D — Pipeline A already provides the seed-averaged signal). This alone cuts new fits from 300 → 100.
2. **3 models, not 5, per new pipeline**: `XGB_D7_MS`, `LGBM_L127`, `ET_Large`. Rationale: XGB and LGBM are the two different boosting families already carrying most of the blend weight, and ET_Large is the only bagging-based (as opposed to boosting-based) model in the current top-5 — it decorrelates differently from both boosters. `LGBM_L255` and `CB_D6` are highly correlated with `LGBM_L127`/`XGB_D7_MS` respectively at the model level, so cloning them across 3 new feature views multiplies fit cost without adding much new disagreement.

This gives **3 pipelines (B, C, D) × 3 models × 5 folds = 45 new model fits**, plus reuse of Pipeline A's OOF/test predictions already computed in V16. Runtime should be a fraction of V16's own training time, since Pipeline C and D are on far fewer columns (600 and 75 vs. 6,850) and only Pipeline B matches A's width.

> [!IMPORTANT]
> If Kaggle time budget is still tight after this cut, drop Pipeline D's separate model bank entirely and instead reuse Pipeline A's k-NN-only feature block by slicing it out of the already-fit Pipeline A models' feature importances — i.e., make D "free" by re-deriving it from A's cached fold data rather than fitting new models. I've flagged this as a toggle in the notebook structure below (`SKIP_PIPELINE_D_REFIT`).

### Blending Strategy — Flat Pool, Not Blend-of-Blends

Your draft describes combining "4 pipeline-level predictions" — i.e., first blend within each pipeline (5 models → 1 pipeline prediction), then blend the 4 pipeline predictions together. I'd recommend **against** the two-stage version and for a **flat pool** instead:

- Treat all `Pipeline A (20 models, from V16) + Pipeline B (3 models) + Pipeline C (3 models) + Pipeline D (3 models)` = **29 model-pipeline OOF columns** as one flat matrix.
- Run the *existing* V16 convex-weight optimizer (Dirichlet + SLSQP) and RidgeCV/ElasticNetCV stack directly on this flat 29-column matrix.

Reasoning: collapsing each pipeline to a single prediction before blending throws away information — if `LGBM_L127` on Pipeline C is excellent but `ET_Large` on Pipeline C is mediocre, an intermediate "Pipeline C blend" mixes them together and hides that from the final optimizer. The convex optimizer is cheap to run on 29 columns instead of 4 and will find the true best combination, including e.g. "90% weight on Pipeline A's XGB, 10% on Pipeline C's LGBM" if that's what the OOF data supports. This also matches how V16's existing blending code already works (it operates on `oof_matrix` with one column per model) — extending it to 29 columns instead of 20 is a drop-in change, not new blending logic.

## Honest Expectations Per Pipeline

- **Pipeline B (FP-only)**: should land close to Pipeline A's per-model R² (fingerprints are already the majority of A's feature count), with most of its value coming from *decorrelation*, not raw individual accuracy. Don't expect it to beat A standalone.
- **Pipeline C (Desc-only)**: likely to score visibly lower standalone (RDKit descriptors alone are informative but historically weaker than fingerprints for these targets, per the V15/V16 notebooks). This is fine — its job is to be *right when A is wrong*, not to win outright. Track its OOF R² but don't be alarmed if it's 0.03-0.06 below Pipeline A per target.
- **Pipeline D (k-NN + compact)**: highest variance of the four. With ~75 features it may underperform badly for whichever target has weaker nearest-neighbor structure (this was already flagged in V16 for Egc-specific k-NN models — `KNN_K10`/`KNN_K20` were *removed* from V16 for exactly this failure mode). Treat D as optional/exploratory: compute it, let the convex optimizer decide its weight, and don't be surprised if it gets ~0 weight for one target.

**Expected total gain: +0.003–0.007** on top of 0.902 (more conservative than the original +0.005–0.010 estimate, reflecting the smaller model×pipeline grid above and the likelihood that Pipeline D contributes little for at least one target).

## Notebook Structure (V17)

```
Cell 1:   Imports + seeds (unchanged from V16)
Cell 2:   Data loading + canonicalization + cross-target lookup (unchanged)
Cell 3:   Feature engineering — reuse V16's train_features/test_features as-is
Cell 4:   Feature preprocessing (unchanged)
Cell 5:   OOF cross-target prediction features (unchanged from V16)
Cell 6:   Multi-fingerprint k-NN target feature function (unchanged from V16)
Cell 7:   Target transformation setup (unchanged)
Cell 8:   Model configurations — subset function build_pipeline_model_configs()
          returning only {XGB_D7_MS, LGBM_L127, ET_Large}, single-seed
Cell 9:   NEW — Feature-subset column selectors:
              fp_only_cols(), desc_only_cols(), knn_compact_cols()
          Build X_B, X_C, X_D as column-sliced views of the V16 feature matrix
          (no recomputation of any feature)
Cell 10:  Level-1 GroupKFold CV for Pipeline A — reuse V16's cached OOF/test
          predictions directly (skip refit if V16 artifacts are available)
Cell 11:  NEW — Level-1 GroupKFold CV for Pipelines B, C, D
          (same evaluate_level1_v16 function, called 3x with different X views
          and the 3-model subset; SKIP_PIPELINE_D_REFIT toggle as noted above)
Cell 12:  NEW — Assemble flat 29-column oof_matrix / test_pred_matrix
          (20 cols from A + 3 from B + 3 from C + 3 from D)
Cell 13:  Blending + stacking on the flat matrix (reuse V16's
          optimize_convex_weights + fit_stacking_meta unchanged)
Cell 14:  Results comparison — per-pipeline and per-model R², plus
          flat-pool blend R² vs. V16's 20-model blend R² (ablation check)
Cell 15:  Submission generation + V15/V16/V17 blend
```

## Verification Plan

### Local Verification

1. Compute Pipeline B/C/D OOF predictions; report standalone per-model, per-target R² for all 9 new model-pipeline combos (3 pipelines × 3 models) before touching the blend.
2. Confirm the diversity hypothesis directly: compute pairwise correlation of OOF residuals between Pipeline A's `XGB_D7_MS` and Pipeline C's `XGB_D7_MS`. If residual correlation isn't meaningfully lower than the correlation among V16's existing 20 models, the feature-subset hypothesis isn't paying off and Pipeline C should be reconsidered before spending Kaggle runtime on it.
3. Run the flat 29-column blend locally and compare its OOF R² against V16's 20-column blend OOF R² (0.910 per the V16 notes). Only proceed to Kaggle submission if the flat blend beats that number locally — this is a hard gate, not a nice-to-have, since local OOF is our only pre-submission signal.
4. Ablation: rerun the blend with each of B, C, D excluded one at a time to confirm each pipeline earns its keep (non-zero optimizer weight, positive marginal contribution). Drop any pipeline that the optimizer assigns ~0 weight to across both targets — no point shipping it.

### Kaggle Verification

1. Submit `submission_v17.csv` (V17 flat-pool blend standalone).
2. Submit `submission_v17_blend.csv` (V17 + V15 + V16 equal/optimized blend).
3. Both must beat 0.902 to be accepted; target 0.905-0.909 as a realistic first checkpoint before chasing the full +0.007.

## Open Questions

> [!IMPORTANT]
> **Runtime budget:** even at the reduced 45-fit scope, Pipeline B runs on the same ~6,465-column width as Pipeline A, so its per-fold fit time for XGB/LGBM will be comparable to V16's — the savings come mostly from dropping multi-seed, not from a smaller matrix. If Kaggle time is still tight, cut Pipeline B first (it's the pipeline closest in content to A and likely the smallest marginal contributor) and keep C and D (which are cheap due to small width and target the clearest orthogonal signal).

> [!IMPORTANT]
> **Reuse vs. refit for Pipeline A:** confirm the V16 notebook's OOF/test prediction arrays for all 20 models are saved to disk (e.g. `oof_matrix_v16.npy`, `test_pred_matrix_v16.npy`) so V17 can load them instead of refitting 20 models × 5 folds from scratch. If they weren't persisted, add that persistence to V16 first — refitting Pipeline A adds ~240 unnecessary fits to V17's runtime for zero new information.

> [!IMPORTANT]
> **Decision point after local ablation:** if step 2 above (residual correlation check) shows Pipeline C/D residuals are *not* meaningfully decorrelated from Pipeline A's, the honest move is to stop here and report that the feature-subset hypothesis didn't hold, rather than submitting a bigger, slower notebook for a marginal or zero gain. This plan is written to fail fast on that check before any Kaggle submission is spent.
