
# V16 — Closing the 0.014 Gap: 0.901 → 0.915+

## Current Standing

| Version                 | Kaggle R²       | What Changed                                                       |
| ----------------------- | ---------------- | ------------------------------------------------------------------ |
| V13                     | 0.898            | Our expanded features + teammate's framework                       |
| V14                     | 0.899            | Teammate's exact V3 code                                           |
| V15 blend (V15+V13+V14) | **0.901**  | k-NN target features + cross-target + 19 models + target transform |
| **Rival**         | **0.915**  | Unknown                                                            |
| **Gap remaining** | **+0.014** |                                                                    |

## Diagnosis: Where V15 is Leaving Points on the Table

After reading the full V15 notebook, V14 notebook, the competition brief, and all OOF results, here are the concrete weaknesses:

### Problem 1: Dead-Weight Models Poisoning the Ensemble

V15's 19-model ensemble includes several models that are **actively harmful**, especially for Egc:

| Model          | Tg R² | Egc R²          | Verdict   |
| -------------- | ------ | ---------------- | --------- |
| KNN_K10        | 0.785  | **0.210**  | ❌ Remove |
| KNN_K20        | 0.765  | **-0.049** | ❌ Remove |
| ElasticNet_Reg | 0.703  | 0.715            | ❌ Remove |
| MLP_PCA        | 0.707  | **0.555**  | ❌ Remove |

Even though the convex optimizer should give these zero weight, they add noise to the optimization landscape and can destabilize the Dirichlet search. **Removing them and replacing with high-quality diverse models is the lowest-risk improvement.**

### Problem 2: k-NN Features Use Only One Fingerprint

Currently k-NN target features use **only Morgan R2** (2048 bits). But different fingerprint types capture different aspects of molecular similarity:

- **Morgan R3** — captures larger substructure neighborhoods (better for Tg backbone patterns)
- **MACCS** — pharmacophore-level patterns (better for functional group-driven Egc)
- **FCFP** — feature-class fingerprints (functional group similarity)

Using multiple fingerprints for k-NN would give the model **multiple similarity perspectives**, each producing a different set of "most similar molecules."

### Problem 3: No Systematic Hyperparameter Tuning

The current hyperparameters appear hand-tuned. The top models (XGB_D7_MS at 0.905/0.908, LGBM_L127 at 0.906/0.902) could likely squeeze out +0.002-0.005 each with Optuna-based Bayesian optimization.

### Problem 4: Insufficient Seed Diversity

Only XGB_D7_MS and XGB_D8_MS use multi-seed (2 seeds each). All LGBMs, CatBoost, and ExtraTrees use a single seed. Multi-seed averaging is essentially free variance reduction.

### Problem 5: No Feature Selection

6,775 features are used for both Tg and Egc. Many fingerprint bits and descriptors are pure noise for one or both targets. Feature selection via importance thresholding would improve generalization.

### Problem 6: Cross-Target Model is Under-Powered

The cross-target LightGBM is trained once on all data (no OOF). For the ~5,200 train molecules without actual cross-target values, this introduces train-on-train bias. OOF cross-target predictions would be cleaner.

---

## Proposed Changes (8 Components)

### 🔴 Component 1: Prune Dead-Weight Models, Add Better Diversity

**Remove** (4 models): `KNN_K10`, `KNN_K20`, `ElasticNet_Reg`, `MLP_PCA`

**Add** (5 models with genuinely different error patterns):

```python
# CatBoost with different depth (depth=8, more complex than CB_D6)
"CB_D8": cb.CatBoostRegressor(
    iterations=1400, depth=8, learning_rate=0.020,
    l2_leaf_reg=3.0, rsm=0.30, random_seed=42,
    thread_count=-1, verbose=False
)

# LightGBM with DART boosting (dropout additive regression trees)
"LGBM_DART": lgbm.LGBMRegressor(
    n_estimators=1200, num_leaves=127, max_depth=7,
    learning_rate=0.02, boosting_type="dart",
    drop_rate=0.1, skip_drop=0.5,
    subsample=0.75, colsample_bytree=0.3,
    reg_alpha=1.0, reg_lambda=3.0,
    random_state=42, n_jobs=-1, verbose=-1
)

# XGBoost with Huber loss (robust to outliers, different error pattern)
"XGB_Huber": xgb.XGBRegressor(
    n_estimators=1500, max_depth=7, learning_rate=0.015,
    subsample=0.75, colsample_bytree=0.25, reg_alpha=1.0,
    reg_lambda=3.0, min_child_weight=3,
    objective="reg:pseudohubererror", huber_slope=1.0,
    random_state=42, n_jobs=-1, verbosity=0
)

# LightGBM with Huber loss
"LGBM_Huber": lgbm.LGBMRegressor(
    n_estimators=1600, num_leaves=127, max_depth=7,
    learning_rate=0.018, objective="huber", alpha=0.9,
    subsample=0.75, colsample_bytree=0.25,
    reg_alpha=1.0, reg_lambda=3.0, min_child_samples=15,
    random_state=42, n_jobs=-1, verbose=-1
)

# HistGradientBoosting (sklearn's built-in, handles NaN natively)
"HGB": HistGradientBoostingRegressor(
    max_iter=1500, max_leaf_nodes=127, max_depth=7,
    learning_rate=0.02, min_samples_leaf=15,
    l2_regularization=3.0, max_features=0.3,
    random_state=42
)
```

**Expected: +0.002–0.004** (cleaner ensemble, Huber models provide robustness diversity)

---

### 🔴 Component 2: Multi-Fingerprint k-NN Target Features (HIGH IMPACT)

Currently: k-NN on Morgan R2 only → 7 features.

**Proposed:** Compute k-NN target features separately on **3 fingerprint types**, producing 7×3 = **21 k-NN features**:

```python
# Fingerprint 1: Morgan R2 (existing) — general substructure similarity
knn_features_r2 = knn_target_features(tanimoto_matrix(fp_r2_query, fp_r2_ref), ref_targets)

# Fingerprint 2: Morgan R3 — larger structural neighborhoods
knn_features_r3 = knn_target_features(tanimoto_matrix(fp_r3_query, fp_r3_ref), ref_targets)

# Fingerprint 3: MACCS — pharmacophore-level patterns
knn_features_maccs = knn_target_features(tanimoto_matrix(fp_maccs_query, fp_maccs_ref), ref_targets)
```

Each fingerprint type will find different "most similar" molecules, giving the GBDT **3 independent nearest-neighbor priors**. The model can learn which similarity view is most predictive for each region of chemical space.

> [!IMPORTANT]
> The same anti-leak rule applies: all k-NN computations use only training-fold targets, never validation/test targets. Leave-one-out for training fold rows.

**Expected: +0.003–0.008** (this is the single biggest lever — the original k-NN features were likely the largest contributor to V15's jump from 0.899→0.901)

---

### 🟡 Component 3: Multi-Seed Averaging for All Top Models

Extend multi-seed from 2 models → **all tree-based models** (3 seeds each):

```python
# Instead of:
"LGBM_L127": lambda: [lgbm.LGBMRegressor(..., random_state=42)]

# Use:
"LGBM_L127": lambda: [
    lgbm.LGBMRegressor(..., random_state=42),
    lgbm.LGBMRegressor(..., random_state=100),
    lgbm.LGBMRegressor(..., random_state=2026),
]
```

Apply to: `LGBM_L127`, `LGBM_L255`, `LGBM_L63`, `LGBM_Robust`, `CB_D6`, `ET_Large`, and the new models.

**Expected: +0.001–0.003** (variance reduction, nearly free)

> [!WARNING]
> This will significantly increase training time (~3× for seeded models). On Kaggle's 2-core CPU, we need to ensure total runtime stays under the time limit. May need to reduce `n_estimators` slightly on some models to compensate.

---

### 🟡 Component 4: Optuna Hyperparameter Tuning for Top-2 Models

Run Bayesian optimization on the two highest-weighted models per target type:

**For Tg:** `LGBM_L127` (46.1% weight) and `SVR_PCA` (24.2% weight)
**For Egc:** `XGB_D7_MS` (43.6% weight) and `ET_Large` (20.8% weight)

Tune with Optuna using 3-fold GroupKFold (lighter than 5-fold for speed) with 50-100 trials each:

```python
def objective_lgbm(trial):
    params = {
        'n_estimators': trial.suggest_int('n_estimators', 1200, 2500),
        'num_leaves': trial.suggest_int('num_leaves', 63, 255),
        'max_depth': trial.suggest_int('max_depth', 5, 9),
        'learning_rate': trial.suggest_float('learning_rate', 0.008, 0.05, log=True),
        'subsample': trial.suggest_float('subsample', 0.6, 0.9),
        'colsample_bytree': trial.suggest_float('colsample_bytree', 0.15, 0.5),
        'reg_alpha': trial.suggest_float('reg_alpha', 0.1, 5.0, log=True),
        'reg_lambda': trial.suggest_float('reg_lambda', 0.5, 10.0, log=True),
        'min_child_samples': trial.suggest_int('min_child_samples', 5, 30),
    }
    # Evaluate with 3-fold GroupKFold R²
    ...
```

> [!IMPORTANT]
> The tuned hyperparameters should be **hardcoded** in the final V16 notebook (not tuned at runtime on Kaggle). We tune locally, verify the best params beat V15's OOF, then bake them in. This avoids runtime overhead and ensures reproducibility.

**Expected: +0.002–0.005** per target type

---

### 🟡 Component 5: Feature Importance-Based Selection

After running one round of training with all features, compute aggregate feature importances across the top GBDT models (gain-based for LightGBM/XGBoost, impurity-based for ExtraTrees), then:

1. Remove features that have **zero importance across all models** (likely 30-50% of fingerprint bits)
2. **Separately for Tg and Egc** — different features matter for different physics

```python
# After training all models in the first pass:
importances_tg = aggregate_importances(tg_models)
importances_egc = aggregate_importances(egc_models)

# Keep features with non-trivial importance
tg_selected = importances_tg[importances_tg > threshold].index
egc_selected = importances_egc[importances_egc > threshold].index
```

This is the V11 hypothesis from the competition brief that was **never fully explored**.

**Expected: +0.001–0.003** (noise reduction, better generalization)

---

### 🟢 Component 6: OOF Cross-Target Predictions

Replace the current single-shot cross-target model with proper OOF predictions:

```python
# Instead of training one LightGBM on ALL Egc data and predicting for ALL molecules:
# Use 5-fold OOF to get unbiased cross-target predictions for training molecules

for fold_idx, (tr_idx, va_idx) in enumerate(kfold.split(egc_data)):
    model.fit(egc_features[tr_idx], egc_targets[tr_idx])
    cross_target_oof[va_idx] = model.predict(egc_features[va_idx])
  
# For test: average predictions from all 5 models
```

This eliminates the train-on-train bias in the current cross-target feature.

**Expected: +0.001–0.002**

---

### 🟢 Component 7: Expanded k-NN k-Values and Statistics

Add more granular k values and richer statistics:

```python
KNN_TARGET_KS = (3, 5, 10, 20, 50)  # was (5, 10, 20)

# Additional statistics per fingerprint:
"knn_target_median_k10"       # median instead of mean (robust to outliers)
"knn_target_max_k5"           # max target of top-5 (upper bound signal)
"knn_target_min_k5"           # min target of top-5 (lower bound signal)
"knn_target_range_k10"        # range = max - min (uncertainty signal)
"knn_target_weighted_k5"      # similarity-weighted average of top-5
"knn_target_sim_k3_mean"      # mean similarity of top-3 (confidence signal)
```

**Expected: +0.001–0.002**

---

### 🟢 Component 8: Improved Blending Strategy

Replace the V13+V14+V15 equal blend with optimized weights, and improve the meta-learner:

```python
# 1. Optimize blend weights using Nelder-Mead on a held-out fold
# instead of equal weighting
# (can't validate locally, but we can use OOF R² as proxy)

# 2. Allow the stack α search to go higher than 0.35
for alpha in np.linspace(0.0, 0.50, 51):  # was 0.0 to 0.35
    ...

# 3. Use ElasticNetCV as an alternative meta-learner (in addition to RidgeCV)
# and blend the two meta-learners
```

**Expected: +0.001–0.002**

---

## Expected Impact Summary

| Component                      | Est. Gain               | Risk     | Effort | Priority    |
| ------------------------------ | ----------------------- | -------- | ------ | ----------- |
| 1. Prune + replace models      | +0.002–0.004           | Very Low | Low    | 🔴 Do first |
| 2. Multi-FP k-NN features      | +0.003–0.008           | Low      | Medium | 🔴 Do first |
| 3. Multi-seed averaging        | +0.001–0.003           | Very Low | Low    | 🟡          |
| 4. Optuna tuning               | +0.002–0.005           | Low      | High   | 🟡          |
| 5. Feature selection           | +0.001–0.003           | Low      | Medium | 🟡          |
| 6. OOF cross-target            | +0.001–0.002           | Very Low | Low    | 🟢          |
| 7. Expanded k-NN stats         | +0.001–0.002           | Very Low | Low    | 🟢          |
| 8. Improved blending           | +0.001–0.002           | Low      | Low    | 🟢          |
| **Total (non-additive)** | **+0.008–0.018** | —       | —     | —          |

> [!IMPORTANT]
> Realistic target: **0.907–0.918 Kaggle**. With all components working well, we should comfortably beat the rival's 0.915. The multi-FP k-NN features + cleaned ensemble + Optuna tuning are the three highest-value levers.

---

## Open Questions

> [!IMPORTANT]
> **Runtime budget:** Multi-fingerprint k-NN adds 2 more Tanimoto matrix computations per fold (MACCS is small at 167 bits, but Morgan R3 is 2048 bits). With multi-seed (3 seeds × 20 models × 5 folds = 300 model fits), total runtime could be 4-6 hours on Kaggle. Should I optimize by:
>
> - (a) Reducing folds from 5 to 4?
> - (b) Reducing seeds from 3 to 2?
> - (c) Reducing Optuna trials to 30?
> - (d) All models already pre-tuned offline, no Optuna at Kaggle runtime?

> [!IMPORTANT]
> **Optuna tuning location:** Should I run Optuna tuning locally (in a separate script) and hardcode the best params into V16, or embed the tuning in the Kaggle notebook itself? Local tuning is safer (no runtime budget impact) but requires the same library versions as Kaggle.

> [!IMPORTANT]
> **Feature selection approach:** Two options:
>
> - (a) **Importance thresholding** — fast, simple, remove zero-importance features
> - (b) **Boruta / RFECV** — more thorough but much slower (probably too slow for Kaggle)
>
> I recommend (a) for Kaggle runtime, with the threshold determined offline.

## Notebook Structure (V16)

```
Cell 1:   Imports + seeds
Cell 2:   Data loading + canonicalization + cross-target lookup
Cell 3:   Feature engineering (V13 features, reused)
Cell 4:   Feature preprocessing (unchanged)
Cell 5:   OOF cross-target prediction features (Component 6)
Cell 6:   Multi-fingerprint k-NN target feature function (Components 2+7)
Cell 7:   Target transformation setup (unchanged)
Cell 8:   Model configurations (Components 1+3+4 — pruned+new+multi-seed+tuned)
Cell 9:   Feature selection (Component 5)
Cell 10:  Level-1 GroupKFold CV (per-fold k-NN + impute + scale + train)
Cell 11:  Improved blending + stacking (Component 8)
Cell 12:  Results comparison
Cell 13:  Submission generation + V13/V14/V15 blend
```

## Verification Plan

### Local Verification

1. Run V16 locally with 5-fold GroupKFold and compare OOF R² against V15's 0.910
2. Each component can be toggled on/off to measure individual contribution
3. Per-model R² comparison to verify new models outperform removed ones

### Kaggle Verification

1. Submit `submission_v16.csv` (V16 standalone)
2. Submit `submission_v16_blend.csv` (V16 + V13 + V14 + V15)
3. Both must beat 0.901 to be accepted
