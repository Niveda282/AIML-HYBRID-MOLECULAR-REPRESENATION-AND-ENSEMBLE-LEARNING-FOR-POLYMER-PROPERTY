# Polymer Property Prediction — Competition Rules, Context & Modeling Brief

## 1. What we are trying to solve

We are participating in a Kaggle competition called **Amalgam Round 1 - Polymer Property Prediction**.

The task is to predict two polymer properties from **SMILES strings**:

- **Tg** — glass transition temperature
- **Egc** — electronic band gap

The competition score is based on the **R² score for Tg and Egc**, averaged into one final score.

Our current best Kaggle score is:

> **0.889**

The objective of this document is to give another AI/modeling assistant enough context to independently propose and test a better approach.

---

# 2. HARD COMPETITION RULES

These rules are extremely important. Any proposed model must remain compliant.

## Data

### ONLY official competition data may be used.

Strictly prohibited:

- External datasets
- Public/private polymer property datasets
- Previously prepared datasets
- Data collected outside notebook execution
- External labels
- Any privately obtained test labels
- Any manually created target labels

The complete modeling pipeline must be based on the official competition data.

## Pretrained models and artifacts

Strictly prohibited:

- Pretrained model weights
- Uploaded checkpoints
- Uploaded embeddings
- Uploaded feature files
- Cached tensors
- Processed datasets created outside notebook execution
- Private model artifacts
- External/private files used by the notebook

All model training outputs and artifacts must be generated during notebook execution.

## Public code

Publicly available code can be used only if:

- It does not introduce external data.
- It does not introduce pretrained weights/checkpoints/embeddings/processed artifacts.
- The complete pipeline remains reproducible inside Kaggle.

## Manual intervention

The submission must be generated automatically.

Manual intervention is not permitted during:

- Data loading
- Preprocessing
- Model definition
- Model initialization
- Training/fine-tuning
- Test inference
- Submission generation

## Reproducibility

Every submission must be backed by a Kaggle Notebook.

The notebook must:

- Run end-to-end.
- Require no manual intervention.
- Finish within Kaggle compute/time limits.
- Generate the submitted result itself.
- Explicitly set/document relevant random seeds.
- Have the exact notebook version that generated the submission pinned/defaulted for that submission.

The submission description must link to the notebook.

After the competition, hosts may rerun the pinned/default notebook and compare the reproduced result with the submitted result.

## Submission limits

Current competition rules state:

- Maximum **3 submissions per day**
- Up to **2 final submissions** can be selected for judging.

## Important team/code-sharing caution

Kaggle's foundational rules contain restrictions around privately sharing competition code between separate teams.

Therefore:

> If the person receiving this document is on a different competition team, do **not** privately share competition code or other Competition Code unless the rules explicitly allow it.

This document is intended as a **modeling brief/context**, not as permission to bypass competition code-sharing rules.

---

# 3. Dataset structure

Official training data:

- ~6,171 rows
- Columns:
  - `id`
  - `smiles`
  - `target`
  - `target_type`

Target types:

- `tg`
- `egc`

Approximate training distribution:

- Tg: **4,143**
- Egc: **2,028**

Official test data:

- ~4,115 rows
- Tg: ~2,763
- Egc: ~1,352

There are a small number of duplicate `(smiles, target_type)` records and a small number of structures that occur with both target types.

---

# 4. Core modeling objective

The important strategic point is:

> We are not trying to maximize a local validation score at any cost.

We need a model whose improvement **transfers to Kaggle's hidden test set**.

A model that gets a spectacular local OOF score but loses on Kaggle is considered a failed experiment.

Therefore:

### Kaggle score is the final judge.

Our current confirmed benchmark is:

> **0.889 Kaggle**

Any new idea must beat this score before becoming the new champion.

---

# 5. Current modeling history

## V2 — Morgan + tree model + KNN

Representation:

- RDKit descriptors
- Morgan fingerprints
- LightGBM
- Morgan similarity KNN
- Blending

Kaggle:

> **0.885**

---

## V4 — Multi-model stacking

Base models:

- LightGBM
- XGBoost
- CatBoost
- Ridge
- Morgan KNN

OOF predictions were stacked using a Ridge meta-model.

Kaggle:

> **0.887**

---

## V5 — Mutual-information feature pruning

The Morgan fingerprint space was pruned for tree models using mutual information calculated from the training fold.

Kaggle:

> **0.887**

No meaningful improvement over V4.

---

## V7 — Cross-target / multi-task information

Idea:

Use prediction of the opposite property as an auxiliary feature.

For example:

```text
SMILES → predict Egc → use as feature when predicting Tg
SMILES → predict Tg  → use as feature when predicting Egc
```

For structures where the opposite target is already present in official training data, the official value can be used as the cross-target feature.

Kaggle:

> **0.888**

This showed that cross-target information is useful but relatively weak.

---

## V8 — GNN

A graph neural network was trained from scratch using molecular graph information.

Kaggle:

> **0.881**

Rejected.

The experiment was computationally expensive without improving the leaderboard.

---

## V9-A — Expanded chemical features

This is currently the strongest foundation.

Representation:

### RDKit descriptors

Standard RDKit molecular descriptors.

### Morgan fingerprints

- Morgan radius 2
- 2,048 bits

### Morgan fingerprints

- Morgan radius 3
- 2,048 bits

### MACCS

- 167-bit MACCS fingerprint

### Explicit polymer/chemistry features

Examples include:

- Number of aromatic atoms
- Number of aromatic rings
- Number of aliphatic rings
- Number of saturated rings
- C/N/O/S/F/Cl/Br/Si/P counts
- Aromatic ratio
- Heteroatom ratio
- N ratio
- O ratio
- Double bond count
- Aromatic bond count
- Double bond ratio
- Aromatic bond ratio
- Rotatable bond count
- Rotatable bond ratio
- Amide count
- Ester count
- Backbone length
- Backbone ratio
- Backbone ring fraction
- Backbone aromatic fraction
- Molecular weight per backbone
- Molecular weight per heavy atom
- Spiro atom count
- Bridgehead count
- HBA
- HBD
- TPSA
- LogP
- Ring count
- Sulfone flag
- Imide flag
- Fluorine flag
- CF3 flag
- Silicon flag

The feature matrix is explicitly aligned between train and test.

Train-only preprocessing is used for cleaning/imputation.

Model:

- LightGBM
- 5-fold random KFold OOF evaluation
- Separate Tg and Egc models

Kaggle:

> **0.889 — CURRENT CHAMPION**

---

## V9-B — Tree diversity

V9-A features plus:

- ExtraTrees
- RandomForest
- LightGBM

The additional tree-family diversity did not improve the leaderboard.

Kaggle:

> **0.889**

Tie with V9-A.

---

## V9-C — GroupKFold audit

We tested structural grouping using Morgan similarity/Butina clustering.

Result:

- Random KFold gave approximately 0.890 local mean.
- Cluster-aware validation dropped to approximately 0.857 mean.

This indicates the dataset contains strong structural similarity between train/validation examples.

However:

> Random KFold was much more representative of the actual Kaggle leaderboard behavior.

Therefore random 5-fold remains our primary competition validation strategy, while structure-aware validation is treated as a robustness diagnostic.

---

## V9-D — Conservative OOF stacking

V9-A features were combined with:

- LightGBM
- XGBoost
- CatBoost
- Ridge

Local OOF results looked extremely promising.

Approximately:

- Equal blend: **0.893**
- Ridge stack: **0.899**

However Kaggle gave:

- Equal blend: **0.883**
- Ridge stack: **0.888**

Conclusion:

> The flexible OOF stacking system was over-optimistic and did not transfer to hidden test data.

This is an important lesson.

Do NOT assume:

```text
higher OOF R² = higher Kaggle R²
```

---

## V10 — Expanded features + cross-target signal

V10 combined the V9-A representation with V7-style cross-target information.

Instead of using an unconstrained meta-model, we used a conservative correction:

```text
final = V9-A + alpha × (V10 - V9-A)
```

with small alpha values.

Kaggle:

> **0.889**

Therefore V10 tied V9-A.

Conclusion:

> Cross-target information is not strong enough to improve the current champion.

---

# 6. Current benchmark

## 🏆 Champion: V9-A

### Kaggle score

**0.889**

This must be treated as the baseline to beat.

Do not replace it because of a higher local OOF score.

---

# 7. Important structural findings

## Canonicalization

SMILES strings can represent the same molecular structure in different textual forms.

We therefore canonicalize SMILES using RDKit when looking for exact structural matches.

Findings from the dataset audit:

- Only a handful of raw SMILES strings overlap directly between train/test.
- Hundreds of test structures have canonical structural overlap with training structures when target type is ignored.
- Same-target canonical overlap is very small.
- Some structures appear in training with both Tg and Egc.

This makes canonical structural matching potentially useful.

### Safe rule

Exact same-target canonical matches can use the official training label.

For example:

```text
(test canonical structure, tg)
```

matching:

```text
(train canonical structure, tg)
```

can safely use the official Tg label.

This is not external information.

---

# 8. Current modeling philosophy

We are now in the stage where random model proliferation is not desirable.

We have already tested:

- Basic descriptor models
- Morgan fingerprints
- KNN
- LightGBM
- XGBoost
- CatBoost
- Ridge
- ExtraTrees
- RandomForest
- GNN
- Cross-target modeling
- GroupKFold
- OOF stacking
- Target transformations
- Feature pruning

The strongest confirmed improvement came from:

> **better chemical representation**

rather than simply adding more models.

Therefore future experiments should be:

1. Small.
2. Controlled.
3. Scientifically motivated.
4. Easy to reproduce.
5. Compared directly against V9-A.
6. Tested on Kaggle before being accepted.

---

# 9. Current hypothesis for the next experiment

## V11 — Target-specific feature optimization

The current V9-A representation is mostly shared between Tg and Egc.

However, the physical chemistry of the two properties is different.

### Tg may depend strongly on:

- Backbone rigidity
- Rotational freedom
- Aromaticity
- Ring structure
- Intermolecular interactions
- Hydrogen bonding
- Molecular flexibility
- Backbone architecture

### Egc may depend strongly on:

- Conjugation
- Aromatic systems
- Heteroatoms
- Electron-withdrawing groups
- Bond environments
- Unsaturation
- Specific functional groups

Therefore the next hypothesis is:

```text
                 V9-A expanded representation
                           │
              ┌────────────┴────────────┐
              ▼                         ▼
        Tg-specific selection      Egc-specific selection
              │                         │
              ▼                         ▼
          Tg model                  Egc model
```

The goal is NOT to blindly remove features.

Instead:

- Measure feature usefulness separately for Tg and Egc.
- Identify whether target-specific feature selection improves generalization.
- Compare against the untouched V9-A representation.
- Keep the original V9-A model as the fallback.

---

# 10. Recommended experimental discipline

For every new version:

## Step 1 — State one hypothesis

Example:

> "Target-specific feature selection may remove noisy features that are irrelevant to Tg while preserving Egc-relevant chemistry."

## Step 2 — Keep everything else fixed

Do not simultaneously change:

- Features
- Validation split
- Model family
- Hyperparameters
- Target transformation
- Ensemble strategy

unless the experiment explicitly targets that combination.

## Step 3 — Run local OOF evaluation

Use:

- 5-fold KFold
- shuffle=True
- random_state=42
- separate Tg/Egc evaluation

Record:

```text
Tg R²
Egc R²
Mean R²
```

## Step 4 — Compare with V9-A

Do not compare only against the previous experiment.

Always compare with:

> **V9-A = 0.889 Kaggle**

## Step 5 — Submit only meaningful candidates

We have a limited submission budget.

Do not waste submissions on tiny local differences without a strong hypothesis.

## Step 6 — Kaggle decides

Possible outcomes:

```text
< 0.889 → reject
= 0.889 → tie, keep V9-A as reference
> 0.889 → investigate and potentially promote
```

---

# 11. What NOT to do

Avoid repeating these approaches unless there is a genuinely new justification:

### ❌ Huge unconstrained stacking

The V9-D experiment demonstrated that an excellent OOF score can fail to transfer.

### ❌ Massive random weight search

For example, 50,000 random ensemble weights selected on the same OOF predictions can heavily optimize validation noise.

### ❌ Adding many model families without evidence

More models do not automatically mean more generalization.

### ❌ GNN just because it is sophisticated

The from-scratch GNN experiment scored 0.881.

### ❌ GroupKFold as the primary leaderboard optimizer

It was useful as a robustness audit but substantially underpredicted the competition setting.

### ❌ External polymer databases

Strictly prohibited.

### ❌ Pretrained chemistry models

Strictly prohibited if they introduce pretrained weights/artifacts.

### ❌ Hand-labeling or inspecting test targets

Strictly prohibited.

---

# 12. What a good new approach should look like

A strong proposal should answer:

1. **What information are we currently missing?**
2. **Why should that information matter specifically for Tg/Egc?**
3. **Can it be computed entirely from the official competition data?**
4. **Can it run entirely inside a Kaggle notebook?**
5. **Can it be evaluated without leakage?**
6. **Why should it generalize better than the current V9-A system?**
7. **What single experiment can test the hypothesis?**

Prefer:

> One strong idea → one controlled experiment → Kaggle validation.

Instead of:

> 20 models → giant ensemble → huge local score → unknown generalization.

---

# 13. Resources/starting point

The current strongest feature construction is based on the V9-A notebook.

The important representation is:

```text
RDKit descriptors
+
Morgan R2 (2048)
+
Morgan R3 (2048)
+
MACCS (167)
+
custom polymer descriptors
```

The current primary model is LightGBM with approximately:

```python
n_estimators=450
learning_rate=0.03
num_leaves=31
min_child_samples=10
colsample_bytree=0.85
reg_lambda=3.0
```

using separate models for `tg` and `egc`.

Random seed:

```python
42
```

---

# 14. The actual challenge for another AI

You are being asked to act as an **independent competition modeling researcher**.

Your job is NOT simply to produce a complicated model.

Your job is to find a method that can realistically beat:

> **0.889 Kaggle**

under the strict competition rules.

You may propose a completely different architecture if you can justify it, but:

- No external data.
- No pretrained weights.
- No external embeddings.
- No processed external artifacts.
- No manual test labeling.
- Everything must run inside Kaggle.
- The approach must be reproducible.
- The final submission must be generated automatically.

Use the history above to avoid repeating failed experiments.

### Priority

Look for **generalization improvements**, especially improvements that could exploit the chemistry encoded in the SMILES while remaining lightweight enough for Kaggle.

A good target would be:

> **0.890+ Kaggle**

A meaningful breakthrough would be:

> **0.895+ Kaggle**

Do not assume that a local OOF score above 0.90 means the method is better.

---

# 15. Current leaderboard summary

| Version | Main idea | Kaggle |
|---|---|---:|
| V2 | Morgan + LightGBM + KNN | 0.885 |
| V4 | Multi-model stacking | 0.887 |
| V5 | MI feature pruning | 0.887 |
| V7 | Cross-target stacking | 0.888 |
| V8 | GNN + tree ensemble | 0.881 |
| V9-A | Expanded chemical features | **0.889 🏆** |
| V9-B | Tree diversity | 0.889 |
| V9-C | GroupKFold audit | 0.886 |
| V9-D | Conservative OOF stacking | 0.888 |
| V10 | Expanded + cross-target | 0.889 |

---

# 16. Final instruction to the next AI

Please independently analyze this entire context and propose **one or a small number of high-value experiments** that have a realistic chance of beating the 0.889 Kaggle benchmark.

Do not simply recommend a larger ensemble.

For each proposal, explain:

- The hypothesis
- Why it could work
- Why previous experiments did not already test it
- Exact implementation idea
- Expected computational cost
- Leakage risks
- How to validate it
- What result would make us keep/reject it

The ultimate objective is:

> **Find a reproducible, competition-compliant improvement over V9-A's 0.889 Kaggle score.**
